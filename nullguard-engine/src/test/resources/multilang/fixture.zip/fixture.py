# Signed installation fixture. Never executes application code.
